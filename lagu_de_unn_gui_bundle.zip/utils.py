def reverse_dict(data):
    return {v['lagu']: k for k, v in data.items()}